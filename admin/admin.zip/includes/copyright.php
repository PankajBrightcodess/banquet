 <footer style="background: #fff;border-top: 0px solid #dee2e6;color: #869099;padding: 1rem;">
    <!-- <strong>Copyright &copy; 2020 <span style="color:#007bff;">HSN Shop</span>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Designed By :- </b> Brightcode
    </div> -->
  </footer>