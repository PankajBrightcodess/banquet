 <!DOCTYPE html>
<html>
<head lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <?php include 'header-links.php'; ?>
  <title>dashboard</title>
  
</head>
  <body>
    
    <section class="footer">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-6 col-12" style="background: #fd717e!important;">
          <span style="color:white; padding-top: 10px;" >All Rights Reserved @perfect venue</span>
        </div>
        <div class="col-md-6 col-12"  style="background: #fd717e!important;">
          <span style="color:white; padding-top: 10px;">Design & Developed by : <img src="img/logobrightcode.png" style="width:15%;"></span>
        </div>
      </div>
    </div>
  </section>




</body>
</html>